package com.pasteboard.keyboard

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import android.text.Editable
import android.text.TextWatcher

class MainActivity : android.app.Activity() {
    private lateinit var store: SnippetStore
    private lateinit var clipboard: ClipboardManager
    private lateinit var library: LinearLayout
    private lateinit var search: EditText
    private lateinit var editor: EditText
    private lateinit var countLabel: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = SnippetStore(this)
        clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        window.statusBarColor = 0xFFF7F7FC.toInt()
        window.navigationBarColor = 0xFFF7F7FC.toInt()
        if (android.os.Build.VERSION.SDK_INT >= 23) window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        setContentView(buildScreen())
        refreshLibrary()
    }

    private fun buildScreen(): View {
        val scroll = ScrollView(this).apply { isFillViewport = true }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(28))
            setBackgroundColor(0xFFF7F7FC.toInt())
        }
        scroll.addView(page)
        if (android.os.Build.VERSION.SDK_INT >= 21) {
            scroll.setOnApplyWindowInsetsListener { _, insets ->
                page.setPadding(
                    dp(20), dp(22) + insets.systemWindowInsetTop,
                    dp(20), dp(28) + insets.systemWindowInsetBottom
                )
                insets
            }
            scroll.requestApplyInsets()
        }

        page.addView(TextView(this).apply {
            text = "PASTEBOARD"
            textSize = 12f
            letterSpacing = 0.12f
            setTextColor(0xFF5D5FEF.toInt())
            setTypeface(typeface, Typeface.BOLD)
        })
        page.addView(TextView(this).apply {
            text = "Your text.\nAlways ready."
            textSize = 31f
            setLineSpacing(dp(1).toFloat(), 1f)
            setTextColor(0xFF202136.toInt())
            setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(7), 0, dp(6))
        })
        page.addView(TextView(this).apply {
            text = "Save long text once, then insert it from your keyboard anywhere you can type."
            textSize = 14f
            setTextColor(0xFF77798A.toInt())
            setPadding(0, 0, 0, dp(17))
        })

        val setupCard = card()
        setupCard.addView(TextView(this).apply {
            text = "Set up your keyboard"
            textSize = 17f
            setTextColor(0xFF252638.toInt())
            setTypeface(typeface, Typeface.BOLD)
        })
        setupCard.addView(TextView(this).apply {
            text = "1. Enable Pasteboard Keyboard in Android settings.\n2. Choose it from the keyboard switcher when typing."
            textSize = 13f
            setTextColor(0xFF77798A.toInt())
            setPadding(0, dp(7), 0, dp(12))
        })
        val setupActions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        setupActions.addView(actionButton("Enable keyboard", true) {
            runCatching { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) }
                .onFailure { Toast.makeText(this@MainActivity, "Open Android Settings and search for On-screen keyboard.", Toast.LENGTH_LONG).show() }
        }, LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginEnd = dp(7) })
        setupActions.addView(actionButton("Select keyboard", false) {
            (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
        }, LinearLayout.LayoutParams(0, dp(44), 1f))
        setupCard.addView(setupActions)
        page.addView(setupCard, matchWrap().apply { bottomMargin = dp(14) })

        val addCard = card()
        addCard.addView(TextView(this).apply {
            text = "Add text to your library"
            textSize = 17f
            setTextColor(0xFF252638.toInt())
            setTypeface(typeface, Typeface.BOLD)
        })
        addCard.addView(TextView(this).apply {
            text = "Paste or type any length of text. There is no character limit imposed by this app."
            textSize = 13f
            setTextColor(0xFF77798A.toInt())
            setPadding(0, dp(5), 0, dp(10))
        })
        editor = EditText(this).apply {
            hint = "Paste a long message, template, address, code…"
            textSize = 14f
            gravity = Gravity.TOP or Gravity.START
            minLines = 5
            maxLines = 10
            setPadding(dp(12), dp(11), dp(12), dp(11))
            setTextColor(0xFF252638.toInt())
            background = rounded(0xFFFFFFFF.toInt(), 0xFFE3E5EE.toInt(), 13)
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE or android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        }
        addCard.addView(editor, matchWrap().apply { topMargin = dp(2) })
        val editorActions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(9), 0, 0)
        }
        editorActions.addView(actionButton("Save text", true) { saveEditorText() },
            LinearLayout.LayoutParams(0, dp(43), 1f).apply { marginEnd = dp(7) })
        editorActions.addView(actionButton("Import clipboard", false) { importClipboard() },
            LinearLayout.LayoutParams(0, dp(43), 1f))
        addCard.addView(editorActions)
        page.addView(addCard, matchWrap().apply { bottomMargin = dp(14) })

        val libraryCard = card()
        val libraryHeader = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        libraryHeader.addView(TextView(this).apply {
            text = "Saved text"
            textSize = 17f
            setTextColor(0xFF252638.toInt())
            setTypeface(typeface, Typeface.BOLD)
        }, LinearLayout.LayoutParams(0, -2, 1f))
        countLabel = TextView(this).apply {
            textSize = 12f
            setTextColor(0xFF77798A.toInt())
        }
        libraryHeader.addView(countLabel)
        libraryCard.addView(libraryHeader)
        search = EditText(this).apply {
            hint = "Search saved text"
            singleLine = true
            textSize = 14f
            setPadding(dp(12), 0, dp(12), 0)
            background = rounded(0xFFFFFFFF.toInt(), 0xFFE3E5EE.toInt(), 12)
        }
        libraryCard.addView(search, matchWrap().apply {
            topMargin = dp(10)
            bottomMargin = dp(9)
        })
        library = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        libraryCard.addView(library)
        page.addView(libraryCard, matchWrap())

        page.addView(TextView(this).apply {
            text = "Private by design · Stored on this device · No account required"
            textSize = 11f
            gravity = Gravity.CENTER
            setTextColor(0xFF8A8B99.toInt())
            setPadding(0, dp(17), 0, 0)
        })

        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = refreshLibrary(s?.toString().orEmpty())
            override fun afterTextChanged(s: Editable?) = Unit
        })
        return scroll
    }

    private fun saveEditorText() {
        val value = editor.text?.toString().orEmpty()
        if (value.isBlank()) {
            editor.error = "Add some text first"
            return
        }
        runCatching { store.save(value) }
            .onSuccess {
                editor.text?.clear()
                refreshLibrary(search.text?.toString().orEmpty())
                Toast.makeText(this, "Saved ${value.length} characters.", Toast.LENGTH_SHORT).show()
            }
            .onFailure { Toast.makeText(this, "Could not save text: ${it.localizedMessage}", Toast.LENGTH_LONG).show() }
    }

    private fun importClipboard() {
        val value = runCatching {
            val clip = clipboard.primaryClip
            if (clip != null && clip.itemCount > 0) clip.getItemAt(0).coerceToText(this).toString() else ""
        }.getOrDefault("")
        if (value.isBlank()) {
            Toast.makeText(this, "There is no text on the clipboard.", Toast.LENGTH_SHORT).show()
            return
        }
        editor.setText(value)
        editor.setSelection(editor.text.length)
        Toast.makeText(this, "Clipboard text imported.", Toast.LENGTH_SHORT).show()
    }

    private fun refreshLibrary(query: String = searchOrEmpty()): Unit {
        if (!::library.isInitialized) return
        library.removeAllViews()
        val items = store.getAll(query)
        countLabel.text = "${items.size} saved"
        if (items.isEmpty()) {
            library.addView(TextView(this).apply {
                text = if (query.isBlank()) "Your saved text will appear here." else "No saved text matches your search."
                textSize = 13f
                setTextColor(0xFF8A8B99.toInt())
                setPadding(dp(4), dp(13), dp(4), dp(13))
            })
            return
        }
        items.forEach { snippet ->
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(11), dp(9), dp(11), dp(9))
                background = rounded(0xFFFFFFFF.toInt(), 0xFFE9EAF1.toInt(), 12)
            }
            item.addView(TextView(this).apply {
                text = snippet.text
                textSize = 13f
                maxLines = 3
                ellipsize = android.text.TextUtils.TruncateAt.END
                setTextColor(0xFF323348.toInt())
            })
            val controls = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            controls.addView(TextView(this).apply {
                text = "${snippet.text.length} characters"
                textSize = 11f
                setTextColor(0xFF858697.toInt())
            }, LinearLayout.LayoutParams(0, dp(34), 1f))
            controls.addView(actionButton("Copy", true) { copyText(snippet.text) },
                LinearLayout.LayoutParams(dp(75), dp(32)).apply { marginEnd = dp(6) })
            controls.addView(actionButton("Delete", false) {
                store.delete(snippet.id)
                refreshLibrary(search.text?.toString().orEmpty())
            }, LinearLayout.LayoutParams(dp(75), dp(32)))
            item.addView(controls)
            library.addView(item, matchWrap().apply { bottomMargin = dp(7) })
        }
    }

    private fun copyText(value: String) {
        clipboard.setPrimaryClip(ClipData.newPlainText("Saved text", value))
        Toast.makeText(this, "Copied ${value.length} characters.", Toast.LENGTH_SHORT).show()
    }

    private fun searchOrEmpty(): String = if (::search.isInitialized) search.text?.toString().orEmpty() else ""

    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(14), dp(14), dp(14), dp(14))
        background = rounded(0xFFFFFFFF.toInt(), 0xFFE9EAF1.toInt(), 17)
    }

    private fun actionButton(label: String, primary: Boolean, onClick: () -> Unit) = TextView(this).apply {
        text = label
        textSize = 13f
        gravity = Gravity.CENTER
        setTypeface(typeface, Typeface.BOLD)
        setTextColor(if (primary) 0xFFFFFFFF.toInt() else 0xFF4D4F65.toInt())
        background = rounded(if (primary) 0xFF5D5FEF.toInt() else 0xFFF3F4F8.toInt(), 0xFFE1E3EC.toInt(), 11)
        setOnClickListener { onClick() }
    }

    private fun rounded(color: Int, stroke: Int, radius: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
        setStroke(dp(1), stroke)
    }

    private fun matchWrap() = LinearLayout.LayoutParams(-1, -2)
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
