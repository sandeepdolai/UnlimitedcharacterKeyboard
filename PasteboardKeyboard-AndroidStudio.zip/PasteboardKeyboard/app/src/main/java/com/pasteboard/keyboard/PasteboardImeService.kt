package com.pasteboard.keyboard

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.inputmethodservice.InputMethodService
import android.os.Build
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class PasteboardImeService : InputMethodService() {
    private lateinit var store: SnippetStore
    private lateinit var clipboardManager: ClipboardManager
    private lateinit var root: LinearLayout
    private lateinit var body: LinearLayout
    private var clipboardMode = false
    private var shifted = false
    private var symbols = false
    private var secureField = false

    override fun onCreate() {
        super.onCreate()
        store = SnippetStore(this)
        clipboardManager = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    }

    override fun onCreateInputView(): View {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(7), dp(8), dp(9))
            setBackgroundColor(0xFFF1F2F7.toInt())
        }
        body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(buildToolbar())
        root.addView(body, LinearLayout.LayoutParams(-1, -2))
        renderBody()
        return root
    }

    override fun onStartInput(attribute: EditorInfo?, restarting: Boolean) {
        super.onStartInput(attribute, restarting)
        secureField = isSecureField(attribute)
        if (secureField) clipboardMode = false
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        secureField = isSecureField(info)
        if (secureField) clipboardMode = false
        if (::body.isInitialized) renderBody()
        refreshToolbar()
    }

    private fun buildToolbar(): View {
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 0, 0, dp(7))
        }
        if (secureField) {
            bar.addView(chip("Password field", true) { },
                LinearLayout.LayoutParams(0, dp(38), 1f).apply { marginEnd = dp(5) })
            bar.addView(chip("Manage", false) { openManager() },
                LinearLayout.LayoutParams(0, dp(38), 0.75f))
        } else {
            bar.addView(chip(if (clipboardMode) "⌨ Keyboard" else "▦ Clips", true) {
                clipboardMode = !clipboardMode
                renderBody()
                refreshToolbar()
            }, LinearLayout.LayoutParams(0, dp(38), 1f).apply { marginEnd = dp(5) })
            bar.addView(chip("Save clipboard", false) { saveCurrentClipboard() },
                LinearLayout.LayoutParams(0, dp(38), 1f).apply { marginEnd = dp(5) })
            bar.addView(chip("Manage", false) { openManager() },
                LinearLayout.LayoutParams(0, dp(38), 0.75f))
        }
        return bar
    }

    private fun refreshToolbar() {
        if (!::root.isInitialized) return
        if (root.childCount > 0) root.removeViewAt(0)
        root.addView(buildToolbar(), 0)
    }

    private fun renderBody() {
        if (!::body.isInitialized) return
        body.removeAllViews()
        if (secureField) {
            body.addView(infoText("Clipboard is hidden in password fields."))
            renderTypingKeyboard()
            return
        }
        if (clipboardMode) renderSnippetLibrary() else renderTypingKeyboard()
    }

    private fun renderSnippetLibrary() {
        body.addView(TextView(this).apply {
            text = "Your saved text"
            textSize = 14f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(0xFF252638.toInt())
            setPadding(dp(3), dp(2), 0, dp(6))
        })

        val search = EditText(this).apply {
            hint = "Search your saved text"
            textSize = 14f
            singleLine = true
            setPadding(dp(12), 0, dp(12), 0)
            background = rounded(0xFFFFFFFF.toInt(), 0xFFE1E3EC.toInt(), 12)
        }
        body.addView(search, LinearLayout.LayoutParams(-1, dp(42)).apply {
            bottomMargin = dp(7)
        })

        val listHost = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            addView(listHost)
        }
        body.addView(scroll, LinearLayout.LayoutParams(-1, dp(190)))

        fun populate(query: String) {
            listHost.removeAllViews()
            val snippets = store.getAll(query)
            if (snippets.isEmpty()) {
                listHost.addView(infoText(if (query.isBlank()) "No saved text yet. Tap “Save clipboard” or add text in Manage." else "No matching text."))
                return
            }
            snippets.take(60).forEach { snippet ->
                val card = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(dp(10), dp(8), dp(10), dp(8))
                    background = rounded(0xFFFFFFFF.toInt(), 0xFFE4E6EF.toInt(), 12)
                }
                val preview = TextView(this).apply {
                    text = snippet.text.replace('\n', ' ')
                    textSize = 13f
                    maxLines = 2
                    ellipsize = android.text.TextUtils.TruncateAt.END
                    setTextColor(0xFF27283A.toInt())
                }
                val actions = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                }
                actions.addView(TextView(this).apply {
                    text = "${snippet.text.length} characters"
                    textSize = 11f
                    setTextColor(0xFF77798A.toInt())
                }, LinearLayout.LayoutParams(0, dp(32), 1f))
                actions.addView(chip("Paste", true) {
                    val inserted = currentInputConnection?.commitText(snippet.text, 1) ?: false
                    if (!inserted) Toast.makeText(this@PasteboardImeService, "The text field is no longer active.", Toast.LENGTH_SHORT).show()
                }, LinearLayout.LayoutParams(dp(80), dp(32)))
                card.addView(preview)
                card.addView(actions)
                listHost.addView(card, LinearLayout.LayoutParams(-1, -2).apply {
                    bottomMargin = dp(6)
                })
            }
        }
        populate("")
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = populate(s?.toString().orEmpty())
            override fun afterTextChanged(s: Editable?) = Unit
        })
    }

    private fun renderTypingKeyboard() {
        val editorType = currentInputEditorInfo?.inputType ?: InputType.TYPE_CLASS_TEXT
        val numeric = (editorType and InputType.TYPE_MASK_CLASS) == InputType.TYPE_CLASS_NUMBER
        if (numeric) {
            listOf(
                listOf("1", "2", "3"),
                listOf("4", "5", "6"),
                listOf("7", "8", "9"),
                listOf("-", "0", "⌫"),
                listOf("space", ".", "↵")
            ).forEach { row -> addKeyRow(row) }
            return
        }

        val rows = if (symbols) {
            listOf(
                listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "0"),
                listOf("@", "#", "$", "%", "&", "-", "+", "(", ")"),
                listOf("=", "*", "\"", "'", ":", ";", "!", "?", "⌫"),
                listOf("ABC", ",", "space", ".", "↵")
            )
        } else {
            listOf(
                "qwertyuiop".map { it.toString() },
                "asdfghjkl".map { it.toString() },
                listOf("⇧") + "zxcvbnm".map { it.toString() } + "⌫",
                listOf("?123", ",", "space", ".", "↵")
            )
        }
        rows.forEach { addKeyRow(it) }
    }

    private fun addKeyRow(keys: List<String>) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        keys.forEach { key ->
            val weight = when (key) {
                "space" -> 4.2f
                "?123", "ABC", "⇧", "⌫", "↵" -> 1.45f
                else -> 1f
            }
            val view = keyView(key)
            row.addView(view, LinearLayout.LayoutParams(0, dp(43), weight).apply {
                setMargins(dp(2), dp(3), dp(2), dp(3))
            })
        }
        body.addView(row, LinearLayout.LayoutParams(-1, -2))
    }

    private fun keyView(label: String): View = TextView(this).apply {
        text = when (label) {
            "space" -> "English"
            else -> if (shifted && label.length == 1 && label[0].isLetter()) label.uppercase() else label
        }
        textSize = when (label) { "space" -> 12f; "↵", "⌫", "⇧" -> 17f; else -> 18f }
        gravity = Gravity.CENTER
        setTextColor(if (label in listOf("?123", "ABC", "⇧", "⌫", "↵")) 0xFF42445A.toInt() else 0xFF252638.toInt())
        background = rounded(if (label == "↵") 0xFFDADAFE.toInt() else if (label in listOf("?123", "ABC", "⇧", "⌫")) 0xFFE1E3EC.toInt() else 0xFFFFFFFF.toInt(), 0xFFE5E6ED.toInt(), 8)
        setOnClickListener { handleKey(label) }
    }

    private fun handleKey(label: String) {
        val connection = currentInputConnection ?: return
        when (label) {
            "⇧" -> { shifted = !shifted; renderBody() }
            "?123" -> { symbols = true; renderBody() }
            "ABC" -> { symbols = false; renderBody() }
            "space" -> connection.commitText(" ", 1)
            "⌫" -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) connection.deleteSurroundingTextInCodePoints(1, 0)
                else connection.deleteSurroundingText(1, 0)
            }
            "↵" -> {
                val action = currentInputEditorInfo?.imeOptions?.and(EditorInfo.IME_MASK_ACTION) ?: EditorInfo.IME_ACTION_NONE
                if (action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) {
                    connection.performEditorAction(action)
                } else {
                    connection.commitText("\n", 1)
                }
            }
            else -> {
                val value = if (shifted && label.length == 1 && label[0].isLetter()) label.uppercase() else label
                connection.commitText(value, 1)
                if (shifted) { shifted = false; renderBody() }
            }
        }
    }

    private fun saveCurrentClipboard() {
        if (secureField) {
            Toast.makeText(this, "Clipboard is disabled in password fields.", Toast.LENGTH_SHORT).show()
            return
        }
        val clip = try { clipboardManager.primaryClip } catch (_: SecurityException) { null }
        val value = clip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(this)?.toString().orEmpty()
        if (value.isBlank()) {
            Toast.makeText(this, "There is no text on the clipboard.", Toast.LENGTH_SHORT).show()
            return
        }
        runCatching { store.save(value) }
            .onSuccess {
                clipboardMode = true
                renderBody()
                refreshToolbar()
                Toast.makeText(this, "Saved ${value.length} characters.", Toast.LENGTH_SHORT).show()
            }
            .onFailure { Toast.makeText(this, "Could not save this text: ${it.localizedMessage}", Toast.LENGTH_LONG).show() }
    }

    private fun openManager() {
        val intent = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(intent)
    }

    private fun isSecureField(info: EditorInfo?): Boolean {
        val type = info?.inputType ?: return false
        val inputClass = type and InputType.TYPE_MASK_CLASS
        val variation = type and InputType.TYPE_MASK_VARIATION
        return (inputClass == InputType.TYPE_CLASS_TEXT && variation in setOf(
            InputType.TYPE_TEXT_VARIATION_PASSWORD,
            InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD,
            InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD
        )) || (inputClass == InputType.TYPE_CLASS_NUMBER && variation == InputType.TYPE_NUMBER_VARIATION_PASSWORD)
    }

    private fun chip(label: String, primary: Boolean, action: () -> Unit): TextView = TextView(this).apply {
        text = label
        textSize = 12f
        gravity = Gravity.CENTER
        setTypeface(typeface, Typeface.BOLD)
        setTextColor(if (primary) 0xFFFFFFFF.toInt() else 0xFF44465C.toInt())
        background = rounded(if (primary) 0xFF5D5FEF.toInt() else 0xFFFFFFFF.toInt(), 0xFFE2E4ED.toInt(), 12)
        setOnClickListener { action() }
    }

    private fun infoText(message: String) = TextView(this).apply {
        text = message
        textSize = 12f
        setTextColor(0xFF77798A.toInt())
        setPadding(dp(8), dp(8), dp(8), dp(8))
    }

    private fun rounded(color: Int, stroke: Int, radius: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
        setStroke(dp(1), stroke)
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
