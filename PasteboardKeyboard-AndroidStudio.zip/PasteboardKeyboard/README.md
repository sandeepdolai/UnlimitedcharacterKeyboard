# Pasteboard Keyboard (Android)

A local-first Android keyboard with a persistent text library. Save long text once, then insert it into the active text field from the keyboard's Clips panel.

## Features

- Android system keyboard implemented with `InputMethodService`.
- Persistent text snippets stored locally in SQLite.
- No app-level character limit on a saved snippet.
- Search saved snippets and insert an entire entry with one tap.
- Save the current Android clipboard from the keyboard while the IME is active.
- Add or import long text from the companion app.
- QWERTY, symbols, basic number-entry layout, backspace, space, and editor action/enter.
- Clipboard controls are hidden from password fields.
- No network permission, account, analytics, or cloud sync.

## Build

1. Open this folder in Android Studio.
2. Install Android SDK Platform 36 when prompted.
3. Allow Gradle sync to complete.
4. Run the `app` configuration on an Android device or emulator.

The source uses Android Gradle Plugin 8.10.1, Kotlin 2.1.20, and Java 17. The build was not executed in this workspace because Android SDK/Gradle are not installed here.

## Enable the keyboard on your phone

1. Open **Pasteboard Keyboard**.
2. Tap **Enable keyboard** and enable it in Android's on-screen keyboard settings.
3. Return to the app and tap **Select keyboard**.
4. Choose **Pasteboard Keyboard**.
5. In any normal text field, open the keyboard's **Clips** panel, select a saved item, and tap **Paste**.

## Important limits

"No app-level character limit" does not mean literally infinite. Storage is limited by the device, SQLite/database limits, available memory, and the destination app's own text-field limits. Very large pastes may be refused or truncated by the destination app. The keyboard inserts text through Android's `InputConnection.commitText()` API.

Only text that you explicitly save or import is stored by this app. It does not record everything you type. Clipboard access is user-controlled and is used when you tap **Save clipboard** or **Import clipboard**.
